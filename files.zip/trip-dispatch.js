/* ============================================================
   1) FIREBASE CONFIG — Harsh se real config milte hi yahan
      paste kar dena. Abhi placeholder hai.
   ============================================================ */
const firebaseConfig = {
  apiKey: "PASTE_API_KEY_HERE",
  authDomain: "transitops-3c250.firebaseapp.com",
  projectId: "transitops-3c250",
  storageBucket: "transitops-3c250.appspot.com",
  messagingSenderId: "PASTE_SENDER_ID_HERE",
  appId: "PASTE_APP_ID_HERE"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

/* ============================================================
   2) MAP SETUP (Leaflet + OpenStreetMap — free, no API key)
   ============================================================ */
const map = L.map('map').setView([22.9734, 78.6569], 5); // India center
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

let sourceMarker, destMarker, routeLine;

// Free OSM geocoding (Nominatim) — turns place name into lat/lng
async function geocodePlace(placeName) {
  const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(placeName)}`;
  const res = await fetch(url);
  const data = await res.json();
  if (data.length === 0) return null;
  return { lat: parseFloat(data[0].lat), lon: parseFloat(data[0].lon) };
}

async function updateMapForTrip(sourceName, destName) {
  const src = await geocodePlace(sourceName);
  const dst = await geocodePlace(destName);
  if (!src || !dst) return;

  if (sourceMarker) map.removeLayer(sourceMarker);
  if (destMarker) map.removeLayer(destMarker);
  if (routeLine) map.removeLayer(routeLine);

  sourceMarker = L.marker([src.lat, src.lon]).addTo(map).bindPopup("Source: " + sourceName);
  destMarker = L.marker([dst.lat, dst.lon]).addTo(map).bindPopup("Destination: " + destName);
  routeLine = L.polyline([[src.lat, src.lon], [dst.lat, dst.lon]], { color: 'blue' }).addTo(map);

  map.fitBounds(routeLine.getBounds(), { padding: [30, 30] });
}

/* ============================================================
   3) LOAD VEHICLES & DRIVERS INTO DROPDOWNS
      (hides Retired/In Shop vehicles & Suspended/expired drivers)
   ============================================================ */
async function loadVehicles() {
  const select = document.getElementById('vehicleSelect');
  select.innerHTML = '<option value="">-- Select Vehicle --</option>';
  const snapshot = await db.collection('vehicles').get();
  snapshot.forEach(doc => {
    const v = doc.data();
    if (v.status === 'Retired' || v.status === 'In Shop') return; // hide these
    const opt = document.createElement('option');
    opt.value = doc.id;
    opt.textContent = `${v.name || v.regNumber} (max ${v.maxLoadCapacity} kg) - ${v.status}`;
    opt.dataset.maxCapacity = v.maxLoadCapacity;
    opt.dataset.status = v.status;
    select.appendChild(opt);
  });
}

async function loadDrivers() {
  const select = document.getElementById('driverSelect');
  select.innerHTML = '<option value="">-- Select Driver --</option>';
  const snapshot = await db.collection('drivers').get();
  const today = new Date();
  snapshot.forEach(doc => {
    const d = doc.data();
    if (d.status === 'Suspended') return; // block suspended
    if (d.licenseExpiryDate && new Date(d.licenseExpiryDate) < today) return; // block expired
    const opt = document.createElement('option');
    opt.value = doc.id;
    opt.textContent = `${d.name} - ${d.status}`;
    opt.dataset.status = d.status;
    select.appendChild(opt);
  });
}

/* ============================================================
   4) CREATE TRIP (with mandatory validations)
   ============================================================ */
document.getElementById('tripForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errorEl = document.getElementById('formError');
  errorEl.textContent = '';

  const source = document.getElementById('source').value.trim();
  const destination = document.getElementById('destination').value.trim();
  const vehicleSelect = document.getElementById('vehicleSelect');
  const driverSelect = document.getElementById('driverSelect');
  const vehicleId = vehicleSelect.value;
  const driverId = driverSelect.value;
  const cargoWeight = parseFloat(document.getElementById('cargoWeight').value);
  const plannedDistance = parseFloat(document.getElementById('plannedDistance').value);

  // Validation: vehicle/driver selected
  if (!vehicleId || !driverId) {
    errorEl.textContent = "Vehicle aur Driver dono select karo.";
    return;
  }

  // Validation: vehicle already On Trip
  const vehicleOpt = vehicleSelect.selectedOptions[0];
  if (vehicleOpt.dataset.status === 'On Trip') {
    errorEl.textContent = "Ye vehicle already On Trip hai.";
    return;
  }

  // Validation: driver already On Trip
  const driverOpt = driverSelect.selectedOptions[0];
  if (driverOpt.dataset.status === 'On Trip') {
    errorEl.textContent = "Ye driver already On Trip hai.";
    return;
  }

  // Validation: cargo weight <= max capacity
  const maxCapacity = parseFloat(vehicleOpt.dataset.maxCapacity);
  if (cargoWeight > maxCapacity) {
    errorEl.textContent = `Cargo weight (${cargoWeight}kg) vehicle ki max capacity (${maxCapacity}kg) se zyada hai.`;
    return;
  }

  // Save trip as Draft
  await db.collection('trips').add({
    source, destination, vehicleId, driverId,
    cargoWeight, plannedDistance,
    status: 'Draft',
    createdAt: firebase.firestore.FieldValue.serverTimestamp()
  });

  await updateMapForTrip(source, destination);
  document.getElementById('tripForm').reset();
  loadVehicles();
  loadDrivers();
});

/* ============================================================
   5) DISPATCH / COMPLETE / CANCEL — auto status change
   ============================================================ */
async function dispatchTrip(tripId, vehicleId, driverId) {
  await db.collection('trips').doc(tripId).update({ status: 'Dispatched' });
  await db.collection('vehicles').doc(vehicleId).update({ status: 'On Trip' });
  await db.collection('drivers').doc(driverId).update({ status: 'On Trip' });
}

async function completeTrip(tripId, vehicleId, driverId) {
  await db.collection('trips').doc(tripId).update({ status: 'Completed' });
  await db.collection('vehicles').doc(vehicleId).update({ status: 'Available' });
  await db.collection('drivers').doc(driverId).update({ status: 'Available' });
}

async function cancelTrip(tripId, vehicleId, driverId) {
  await db.collection('trips').doc(tripId).update({ status: 'Cancelled' });
  await db.collection('vehicles').doc(vehicleId).update({ status: 'Available' });
  await db.collection('drivers').doc(driverId).update({ status: 'Available' });
}

/* ============================================================
   6) RENDER TRIPS TABLE (live updates via Firestore listener)
   ============================================================ */
function renderTrips() {
  db.collection('trips').orderBy('createdAt', 'desc').onSnapshot(snapshot => {
    const tbody = document.getElementById('tripsBody');
    tbody.innerHTML = '';
    snapshot.forEach(doc => {
      const t = doc.data();
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${t.source}</td>
        <td>${t.destination}</td>
        <td>${t.vehicleId}</td>
        <td>${t.driverId}</td>
        <td>${t.cargoWeight}</td>
        <td class="status-${t.status.toLowerCase()}">${t.status}</td>
        <td>
          ${t.status === 'Draft' ? `<button class="action-btn btn-dispatch" data-id="${doc.id}" data-v="${t.vehicleId}" data-d="${t.driverId}">Dispatch</button>` : ''}
          ${t.status === 'Dispatched' ? `<button class="action-btn btn-complete" data-id="${doc.id}" data-v="${t.vehicleId}" data-d="${t.driverId}">Complete</button>
          <button class="action-btn btn-cancel" data-id="${doc.id}" data-v="${t.vehicleId}" data-d="${t.driverId}">Cancel</button>` : ''}
        </td>
      `;
      tbody.appendChild(tr);
    });

    // wire up buttons (event delegation would be cleaner, this is simplest for beginners)
    document.querySelectorAll('.btn-dispatch').forEach(btn =>
      btn.onclick = () => dispatchTrip(btn.dataset.id, btn.dataset.v, btn.dataset.d));
    document.querySelectorAll('.btn-complete').forEach(btn =>
      btn.onclick = () => completeTrip(btn.dataset.id, btn.dataset.v, btn.dataset.d));
    document.querySelectorAll('.btn-cancel').forEach(btn =>
      btn.onclick = () => cancelTrip(btn.dataset.id, btn.dataset.v, btn.dataset.d));
  });
}

/* ============================================================
   7) INIT
   ============================================================ */
loadVehicles();
loadDrivers();
renderTrips();
